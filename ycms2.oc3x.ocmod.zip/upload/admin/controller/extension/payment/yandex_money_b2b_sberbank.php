<?php

require_once dirname(__FILE__).DIRECTORY_SEPARATOR.'yandex_money.php';

class ControllerExtensionPaymentYandexMoneyB2bSberbank extends ControllerExtensionPaymentYandexMoney
{

}