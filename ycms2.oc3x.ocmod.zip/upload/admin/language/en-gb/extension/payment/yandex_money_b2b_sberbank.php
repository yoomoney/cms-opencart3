<?php
$_['heading_title']    = 'Sberbank Business Online';
$_['text_yandexmoney'] = '<a onclick="window.open(\'https://checkout.yandex.com\');"><img src="view/image/payment/yandexmoney.png" alt="Sberbank Business Online" title="Sberbank Business Online" /></a>';