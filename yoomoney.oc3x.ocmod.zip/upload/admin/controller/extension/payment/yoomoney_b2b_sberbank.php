<?php

require_once dirname(__FILE__).DIRECTORY_SEPARATOR.'yoomoney.php';

class ControllerExtensionPaymentYoomoneyB2bSberbank extends ControllerExtensionPaymentYoomoney
{

}