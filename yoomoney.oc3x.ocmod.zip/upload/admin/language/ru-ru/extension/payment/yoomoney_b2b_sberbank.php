<?php
$_['heading_title']    = 'ЮKassa: Сбербанк Бизнес Онлайн';
$_['text_yoomoney'] = '<a onclick="window.open(\'https://yookassa.ru/\');"><img src="view/image/payment/yoomoney.png" alt="ЮKassa: Сбербанк Бизнес Онлайн" title="ЮKassa: Сбербанк Бизнес Онлайн" /></a>';